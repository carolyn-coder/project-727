# Automatic portal refresh, updated task prompt

August 19, 2026. Replaces the earlier version. The change that matters is **Step 2**: how a Paul Fino meeting gets identified.

---

## Why this changed

The refresh missed the Chrissy x Plan + Pivot touch base because it looked for the words "Paul Fino" and that invite does not contain them. Chrissy Montera runs coordination for this project, so **any meeting she is on is a Paul Fino meeting**, whatever the invite happens to be called. The same holds for the other partner domains.

That rule is now written into the prompt rather than left to inference.

---

## Setup

Open **Scheduled** in the sidebar, open the Paul Fino portal refresh task, and replace the prompt with the block below. Everything else stays as it was: weekdays, approval required until you trust it.

---

## The prompt

```
Refresh the Paul Fino client portal from email, calendar, and meeting notes.

CONTEXT
The portal is a static site whose live content is stored in Supabase project
qrlyqibwschmnrbtltcq, table public.pf_portal_state. Each row is a key with a
JSON string value. You update rows; you never redeploy the site.

Client: Paul Fino, fragrant body care line, launching July 12 2027.
Brand name is IDEAR. Products are the Perfume Mist, Shower Oil, and Body Melk.
The line will be vegan. Custom Essence is the selected fragrance house.

PEOPLE AND DOMAINS
  Nightingale Management  @nightingalemgmt.co
      Paul (founder, sole final decision maker), Jack, Ariana, Jenny
  Miss C-Suite            chrissy@misscsuite.com   (Chrissy Montera)
  Townhouse Collective    danielle@townhousecollective.com
  IPG                     @ipg.biz                 (Damaris is the contact)
  Custom Essence          @customessence.com       (Austin, Mallory)
  Global Source Packaging (Andrew and Heather Perkins)
  Plan + Pivot            carolyn@ and julie@planpivotcollective.com

STEP 1: GATHER EMAIL AND NOTES
- Gmail, last 7 days:
  (fino OR nightingale OR misscsuite OR IPG OR "custom essence"
   OR "global source" OR townhouse OR IDEAR)
- Granola, last 7 days: any meeting involving the people above.
  Pull decisions and action items with their owners.

STEP 2: IDENTIFY THE MEETINGS  <-- READ THIS CAREFULLY
Do NOT search the calendar for the words "Paul Fino". Many of these meetings
are named other things.

A calendar event counts as a Paul Fino meeting if ANY of these is true:
  a) any attendee or the organiser is at one of the partner domains above,
     and most importantly chrissy@misscsuite.com. If Chrissy is on it, it
     counts, whatever the invite is called. "Chrissy X PPC TB" is a Paul
     Fino meeting.
  b) the title or description mentions Fino, IDEAR, fragrance, Custom
     Essence, Chemia, IPG, Townhouse, or packaging in this project's sense
  c) it is a recurring touch base that has historically covered this project

Explicitly EXCLUDE meetings that are only Carolyn and Julie with no partner
present, anything for other clients, and anything personal.

Look forward 4 weeks. For each qualifying meeting capture: title, date, start
and end in ET, the Meet or Zoom link, and the full attendee email list.

STEP 3: UPDATE THESE ROWS
Read each row first, then write back the full JSON. Never blank a row.

1. pf:live:meta
   {"updated":"<today, e.g. August 26, 2026 at 8:00 AM ET>","phase_n":1,
    "phase_total":7,"phase_name":"Foundation and vendor lock"}
   Advance the phase only if notes clearly say a phase gate was passed.

2. pf:live:meetings
   {"next":{...}, "options":[...], "upcoming":[...]}
   next     = the soonest qualifying meeting, with id, month, day, title,
              when, who, link, short, and emails (the full attendee list).
   options  = one entry per qualifying meeting found in step 2, each with
              id, title, when, emails. These drive the agenda meeting picker
              and the recipient list, so the emails array must be the real
              attendee list from the invite.
              ALWAYS keep these four standing options at the end, even when
              no invite exists for them:
                weekly       full project group
                chrissy-tb   Chrissy plus Carolyn and Julie
                nightingale  Paul and Jack only
                all          everyone with portal access
              Preserve the id values exactly. People have agenda items
              attached to them, and changing an id orphans their work.
   upcoming = the next four, confirmed true only if actually on the calendar.

3. pf:live:deliverables
   {"<slug>":{"s":"<status>","by":"<Carolyn|Julie>","at":"YYYY-MM-DD"}, ...}
   Slugs: calendar, pricing, competitive, brief, testing, assortment, model.
   Statuses: Queued, In progress, First pass delivered, Delivered, On hold.
   ONLY change a status when Carolyn or Julie says so in writing. Never infer
   from a client email. If nothing says so, leave this row untouched.

4. pf:live:outstandings
   [{"item":"...","owner":"...","note":"..."}, ...]
   Owners must be one of: Paul, Jack, Miss C-Suite, Plan + Pivot, IPG,
   Townhouse. Remove an item only with clear evidence it landed. Add new ones
   from action items in email and notes. One or two sentences per note,
   explaining why it matters rather than just what it is.

5. pf:agenda
   [{"text":"...","meta":"...","done":false,"due":"YYYY-MM-DD",
     "forMtg":"<option id>"}]
   Read it first. Remove items the notes show were covered, add new topics
   with meta naming the source, and keep anything a person added themselves.
   NEVER touch the forMtg field on an existing item. That is Carolyn and
   Julie assigning items to a specific meeting, and overwriting it wipes
   their prep.

RULES
- Never invent. If email and notes disagree, keep what is there and flag it.
- Spelling comes from the Brand Brief, not from Granola, which transcribes
  spoken names phonetically. IDEAR and MELKY are correct.
- Never write fee amounts, other client names, or Plan + Pivot's internal
  hours into the portal. The whole partner group reads it.
- No em-dashes. Use commas, periods, or two sentences.
- Say "the briefs" and "the calendar", not "your briefs". Refer to Paul by
  name.
- Neutral and forward-looking. Name what needs to happen next rather than
  what has gone wrong.

STEP 4: REPORT BACK
Give Carolyn a short summary: what changed, what closed, what is new, which
meetings you found and which you judged out of scope, and anything ambiguous
enough that a human should check it. If nothing changed, say so in one line
and do not write to the database.
```

---

## What I fixed by hand today

The picker now lists both real invites plus three standing options:

| Option | Recipients |
|---|---|
| Fragrance briefing, Mon Aug 24 | 10, from Chrissy's invite |
| Chrissy x Plan + Pivot TB, Wed Aug 19 | 3 |
| Weekly touch base, full group | 7 |
| Paul and Jack only | 2 |
| Everyone with portal access | 7 |

Already live on the site, so no redeploy is needed for this part.

---

## One thing worth deciding

The Chrissy touch base on August 19 was a one-off, not a recurring invite. Neither is the weekly touch base with the full group. That means the only Paul Fino session currently on the calendar is the August 24 briefing.

Making the Chrissy touch base recurring would give the task a reliable weekly anchor to attach agenda items to, and would close the cadence item that has been sitting on the outstandings list since the twelfth.
